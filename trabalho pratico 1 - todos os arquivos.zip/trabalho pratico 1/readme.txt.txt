para rodar o código em python, primeiro é necessário criar o banco de dados com o postgres (conforme o arquivo .sql disponibilizado)

Depois, é só executar o main.py e popular o banco de dados (para popular a tabela gastos, vc precisa obter o json)

O json para os gastos são pesados e não consigo fazer upload no github, mas eles podem ser baixados no link: 
https://dadosabertos.camara.leg.br/swagger/api.html#staticfile

Veja o código na função de inserir gastos para tirar duvidas (no arquivo Deputados.py)

O vídeo de explicação está no link: https://youtu.be/Szef5xqjmcI